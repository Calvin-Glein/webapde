package edu.voteer.beans;

import java.io.Serializable;

public class Video implements Serializable{
	public static final String VIDEO_VIDEO_ID = "video_id";
	public static final String VIDEO_CANDIDATE_ID = "candidate_id";
	public static final String VIDEO_TITLE ="title";
	public static final String VIDEO_DESCRIPTION = "description";
	public static final String VIDEO_URL = "url";
	
	private int video_id;
	private int candidate_id;
	private String title;
	private String description;
	private String url;
	
	public Video(){
		
	}

	public Video(int video_id, int candidate_id, String title, String description, String url) {
		super();
		this.video_id = video_id;
		this.candidate_id = candidate_id;
		this.title = title;
		this.description = description;
		this.url = url;
	}

	public int getVideo_id() {
		return video_id;
	}

	public void setVideo_id(int video_id) {
		this.video_id = video_id;
	}

	public int getCandidate_id() {
		return candidate_id;
	}

	public void setCandidate_id(int candidate_id) {
		this.candidate_id = candidate_id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
	
	

}
