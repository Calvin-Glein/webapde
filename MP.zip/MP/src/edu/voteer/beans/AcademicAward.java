package edu.voteer.beans;

import java.io.Serializable;

public class AcademicAward implements Serializable{
	public static final String ACADEMICAWARD_TABLE_NAME = "academic_awards";
	public static final String ACADEMICAWARD_ACADEMIC_AWARD_ID = "academic_award_id";
	public static final String ACADEMICAWARD_ACADEMIC_ID = "academic_id";
	public static final String ACADEMICAWARD_AWARD_TITLE = "award_title";
	
	private int academic_award_id;
	private int academic_id;
	private String award_title;
	
	public AcademicAward(){
		
	}
	
	public AcademicAward(int academic_award_id, int academic_id, String award_title) {
		super();
		this.academic_award_id = academic_award_id;
		this.academic_id = academic_id;
		this.award_title = award_title;
	}
	public int getAcademic_award_id() {
		return academic_award_id;
	}
	public void setAcademic_award_id(int academic_award_id) {
		this.academic_award_id = academic_award_id;
	}
	public int getAcademic_id() {
		return academic_id;
	}
	public void setAcademic_id(int academic_id) {
		this.academic_id = academic_id;
	}
	public String getAward_title() {
		return award_title;
	}
	public void setAward_title(String award_title) {
		this.award_title = award_title;
	}
	
	
}
