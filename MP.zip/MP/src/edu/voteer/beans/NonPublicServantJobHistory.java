package edu.voteer.beans;

import java.io.Serializable;

public class NonPublicServantJobHistory implements Serializable {
	public static final String NONPUBLICSERVANTJOBHISTORY_NON_PUBLIC_SERVANT_JOB_HISTORY_ID = "non_public_servant_job_history_id";
	public static final String NONPUBLICSERVANTJOBHISTORY_CANDIDATE_ID = "candidate_id";
	public static final String NONPUBLICSERVANTJOBHISTORY_POSITION = "position";

	private int non_public_servant_job_history_id;
	private int candidate_id;
	private int position;
	
	public NonPublicServantJobHistory(){
		
	}
	
	public NonPublicServantJobHistory(int non_public_servant_job_history_id, int candidate_id, int position) {
		super();
		this.non_public_servant_job_history_id = non_public_servant_job_history_id;
		this.candidate_id = candidate_id;
		this.position = position;
	}

	public int getNon_public_servant_job_history_id() {
		return non_public_servant_job_history_id;
	}

	public void setNon_public_servant_job_history_id(int non_public_servant_job_history_id) {
		this.non_public_servant_job_history_id = non_public_servant_job_history_id;
	}

	public int getCandidate_id() {
		return candidate_id;
	}

	public void setCandidate_id(int candidate_id) {
		this.candidate_id = candidate_id;
	}

	public int getPosition() {
		return position;
	}

	public void setPosition(int position) {
		this.position = position;
	}
	
	
	
	
}
