package edu.voteer.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import edu.voteer.beans.Academic;
import edu.voteer.beans.Candidate;
import edu.voteer.db.DBPool;

public class AcademicService {
	public static void addCandidate(Academic a) {
		String sql = "INSERT INTO " + Academic.ACADEMIC_TABLE_NAME + " (" + Academic.ACADEMIC_CANDIDATE_ID + ", "
				+ Academic.ACADEMIC_DEGREE + ") VALUES (?, ?)";

		Connection conn = DBPool.getInstance().getConnection();

		// use preparedstatement to prevent sql injection

		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);

			pstmt.setInt(2, a.getCandidate_id());
			pstmt.setString(3, a.getDegree());

			pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	public static ArrayList<Academic> getAllAcademic() {
		ArrayList<Academic> academics = new ArrayList<>();

		String sql = "Select * from " + Academic.ACADEMIC_TABLE_NAME + ";";

		Connection conn = DBPool.getInstance().getConnection();

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				Academic a = new Academic();
				a.setAcademic_id(rs.getInt(Academic.ACADEMIC_ACADEMIC_ID));
				a.setCandidate_id(rs.getInt(Academic.ACADEMIC_CANDIDATE_ID));
				a.setDegree(rs.getString(Academic.ACADEMIC_DEGREE));

				academics.add(a);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return academics;
	}
}
