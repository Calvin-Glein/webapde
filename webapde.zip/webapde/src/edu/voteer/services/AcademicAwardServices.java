package edu.voteer.services;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import edu.voteer.beans.Academic;
import edu.voteer.beans.AcademicAward;
import edu.voteer.db.DBPool;


public class AcademicAwardServices {
	public static void addAcademicAward(AcademicAward a) {
		String sql = "INSERT INTO " + AcademicAward.ACADEMICAWARD_TABLE_NAME + " (" + Academic.ACADEMIC_ACADEMIC_ID + ", "
				+ AcademicAward.ACADEMICAWARD_AWARD_TITLE + ") VALUES (?, ?)";

		Connection conn = DBPool.getInstance().getConnection();

		// use preparedstatement to prevent sql injection

		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, a.getAcademic_id());
			pstmt.setString(2, a.getAward_title());

			pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	public static ArrayList<AcademicAward> getAllAcademicAward() {
		ArrayList<AcademicAward> academicAwards = new ArrayList<>();

		String sql = "Select * from " + AcademicAward.ACADEMICAWARD_TABLE_NAME + ";";

		Connection conn = DBPool.getInstance().getConnection();

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				AcademicAward a = new AcademicAward();
				a.setAcademic_award_id(rs.getInt(AcademicAward.ACADEMICAWARD_ACADEMIC_AWARD_ID));
				a.setAcademic_id(rs.getInt(AcademicAward.ACADEMICAWARD_ACADEMIC_ID));
				a.setAward_title(rs.getString(AcademicAward.ACADEMICAWARD_AWARD_TITLE));

				academicAwards.add(a);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return academicAwards;
	}
	public static void updateAcademicAward(AcademicAward a) {
		String sql = "UPDATE " + AcademicAward.ACADEMICAWARD_TABLE_NAME + " SET "
				+ AcademicAward.ACADEMICAWARD_ACADEMIC_ID + " = ?, " + AcademicAward.ACADEMICAWARD_AWARD_TITLE
				+ " = ? " + " WHERE " + AcademicAward.ACADEMICAWARD_ACADEMIC_AWARD_ID + " = ?;";

		Connection conn = DBPool.getInstance().getConnection();
		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, a.getAcademic_id());
			pstmt.setString(2, a.getAward_title());
			pstmt.setString(3, a.getAward_title());
		
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}

	public static void deleteAcademicAward(int academic_award_id) {
		
		String sql = "DELETE FROM " + AcademicAward.ACADEMICAWARD_TABLE_NAME + " WHERE "
				+ AcademicAward.ACADEMICAWARD_ACADEMIC_AWARD_ID + " =?";

		Connection conn = DBPool.getInstance().getConnection();

		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, academic_award_id);
			

			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}

	}
}
