package edu.voteer.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import edu.voteer.beans.NonPublicServantJobHistory;
import edu.voteer.db.DBPool;

public class NonPublicServantJobHistoryServices {
	public static void addNonPublicServantJobHistory(NonPublicServantJobHistory n) {
		String sql = "INSERT INTO " + NonPublicServantJobHistory.NONPUBLICSERVANTJOBHISTORY_TABLE_NAME + " ("
				+ NonPublicServantJobHistory.NONPUBLICSERVANTJOBHISTORY_CANDIDATE_ID + ", "
				+ NonPublicServantJobHistory.NONPUBLICSERVANTJOBHISTORY_POSITION + ", "
				+ NonPublicServantJobHistory.NONPUBLICSERVANTJOBHISTORY_INSTITUTION + ") VALUES (?, ?, ?)";

		Connection conn = DBPool.getInstance().getConnection();

		// use preparedstatement to prevent sql injection

		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, n.getCandidate_id());
			pstmt.setString(2, n.getPosition());
			pstmt.setString(3, n.getInstitution());

			pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	public static ArrayList<NonPublicServantJobHistory> getAllNonPublicServantJobHistory() {
		ArrayList<NonPublicServantJobHistory> nonPublicServantJobHistories = new ArrayList<>();

		String sql = "Select * from " + NonPublicServantJobHistory.NONPUBLICSERVANTJOBHISTORY_TABLE_NAME + ";";

		Connection conn = DBPool.getInstance().getConnection();

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				NonPublicServantJobHistory n = new NonPublicServantJobHistory();
				n.setNon_public_servant_job_history_id(
						rs.getInt(NonPublicServantJobHistory.NONPUBLICSERVANTJOBHISTORY_CANDIDATE_ID));
				n.setCandidate_id(rs.getInt(NonPublicServantJobHistory.NONPUBLICSERVANTJOBHISTORY_CANDIDATE_ID));
				n.setPosition(rs.getString(NonPublicServantJobHistory.NONPUBLICSERVANTJOBHISTORY_POSITION));
				n.setInstitution(rs.getString(NonPublicServantJobHistory.NONPUBLICSERVANTJOBHISTORY_INSTITUTION));

				nonPublicServantJobHistories.add(n);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return nonPublicServantJobHistories;
	}

	public static void updateNonPublicServantJobHistory(NonPublicServantJobHistory n) {
		String sql = "UPDATE " + NonPublicServantJobHistory.NONPUBLICSERVANTJOBHISTORY_TABLE_NAME + " SET "
				+ NonPublicServantJobHistory.NONPUBLICSERVANTJOBHISTORY_CANDIDATE_ID + " = ?, "
				+ NonPublicServantJobHistory.NONPUBLICSERVANTJOBHISTORY_INSTITUTION + " = ?, "
				+ NonPublicServantJobHistory.NONPUBLICSERVANTJOBHISTORY_POSITION + " = ? " + " WHERE "
				+ NonPublicServantJobHistory.NONPUBLICSERVANTJOBHISTORY_NON_PUBLIC_SERVANT_JOB_HISTORY_ID + " = ?;";

		Connection conn = DBPool.getInstance().getConnection();
		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, n.getCandidate_id());
			pstmt.setString(2, n.getInstitution());
			pstmt.setString(3, n.getPosition());
			pstmt.setInt(4, n.getNon_public_servant_job_history_id());

			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}

	public static void deleteNonPublicServantJobHistory(int non_public_servant_job_history_id) {

		String sql = "DELETE FROM " + NonPublicServantJobHistory.NONPUBLICSERVANTJOBHISTORY_TABLE_NAME + " WHERE "
				+ NonPublicServantJobHistory.NONPUBLICSERVANTJOBHISTORY_NON_PUBLIC_SERVANT_JOB_HISTORY_ID + " =?";

		Connection conn = DBPool.getInstance().getConnection();

		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, non_public_servant_job_history_id);

			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}

	public static ArrayList<NonPublicServantJobHistory> getAllNonPublicServantJobHistoryByCandidate(int candidate_id) {
		ArrayList<NonPublicServantJobHistory> nonPublicServantJobHistories = new ArrayList<>();

		String sql = "Select * from " + NonPublicServantJobHistory.NONPUBLICSERVANTJOBHISTORY_TABLE_NAME
				+ " where candidate_id = ?;";

		Connection conn = DBPool.getInstance().getConnection();

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, candidate_id);

			rs = pstmt.executeQuery();

			while (rs.next()) {
				NonPublicServantJobHistory n = new NonPublicServantJobHistory();
				n.setNon_public_servant_job_history_id(
						rs.getInt(NonPublicServantJobHistory.NONPUBLICSERVANTJOBHISTORY_CANDIDATE_ID));
				n.setCandidate_id(rs.getInt(NonPublicServantJobHistory.NONPUBLICSERVANTJOBHISTORY_CANDIDATE_ID));
				n.setPosition(rs.getString(NonPublicServantJobHistory.NONPUBLICSERVANTJOBHISTORY_POSITION));
				n.setInstitution(rs.getString(NonPublicServantJobHistory.NONPUBLICSERVANTJOBHISTORY_INSTITUTION));

				nonPublicServantJobHistories.add(n);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return nonPublicServantJobHistories;
	}
}
