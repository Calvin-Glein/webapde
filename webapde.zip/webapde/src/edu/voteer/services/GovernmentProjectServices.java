package edu.voteer.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import edu.voteer.beans.GovernmentProject;
import edu.voteer.db.DBPool;

public class GovernmentProjectServices {
	public static void addGovernmentProject(GovernmentProject g) {
		String sql = "INSERT INTO " + GovernmentProject.GOVERNMENTPROJECT_GOVERNMENTPROJECT_TABLE_NAME + " ("
				+ GovernmentProject.GOVERNMENTPROJECT_CANDIDATE_ID + ", " + GovernmentProject.GOVERNMENTPROJECT_TITLE
				+ ", " + GovernmentProject.GOVERNMENTPROJECT_DESCRIPTION + ") VALUES (?, ?,?)";

		Connection conn = DBPool.getInstance().getConnection();

		// use preparedstatement to prevent sql injection

		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, g.getCandidate_int());

			pstmt.setString(2, g.getTitle());
			pstmt.setString(3, g.getDescription());

			pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	public static ArrayList<GovernmentProject> getAllGovernmentProject() {
		ArrayList<GovernmentProject> governmentProjects = new ArrayList<>();

		String sql = "Select * from " + GovernmentProject.GOVERNMENTPROJECT_GOVERNMENTPROJECT_TABLE_NAME + ";";

		Connection conn = DBPool.getInstance().getConnection();

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				GovernmentProject g = new GovernmentProject();
				g.setGovernment_project_id(rs.getInt(GovernmentProject.GOVERNMENTPROJECT_GOVERNMENT_PROJECT_ID));
				g.setCandidate_int(rs.getInt(GovernmentProject.GOVERNMENTPROJECT_CANDIDATE_ID));
				g.setTitle(rs.getString(GovernmentProject.GOVERNMENTPROJECT_TITLE));
				g.setDescription(rs.getString(GovernmentProject.GOVERNMENTPROJECT_DESCRIPTION));

				governmentProjects.add(g);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return governmentProjects;
	}

	public static void updateGovernmentProject(GovernmentProject g) {
		String sql = "UPDATE " + GovernmentProject.GOVERNMENTPROJECT_GOVERNMENTPROJECT_TABLE_NAME + " SET "
				+ GovernmentProject.GOVERNMENTPROJECT_CANDIDATE_ID + " = ?, "
				+ GovernmentProject.GOVERNMENTPROJECT_TITLE + " = ?, " + GovernmentProject.GOVERNMENTPROJECT_DESCRIPTION
				+ " = ? " + " WHERE " + GovernmentProject.GOVERNMENTPROJECT_GOVERNMENT_PROJECT_ID + " = ?;";

		Connection conn = DBPool.getInstance().getConnection();
		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, g.getCandidate_int());
			pstmt.setString(2, g.getTitle());
			pstmt.setString(3, g.getDescription());
			pstmt.setInt(4, g.getGovernment_project_id());

			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}

	public static void deleteGovernmentProject(int government_project_id) {

		String sql = "DELETE FROM " + GovernmentProject.GOVERNMENTPROJECT_GOVERNMENTPROJECT_TABLE_NAME + " WHERE "
				+ GovernmentProject.GOVERNMENTPROJECT_GOVERNMENT_PROJECT_ID + " =?";

		Connection conn = DBPool.getInstance().getConnection();

		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, government_project_id);

			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}

	public static ArrayList<GovernmentProject> getAllGovernmentProjectByCandidate(int candidate_id) {
		ArrayList<GovernmentProject> governmentProjects = new ArrayList<>();

		String sql = "Select * from " + GovernmentProject.GOVERNMENTPROJECT_GOVERNMENTPROJECT_TABLE_NAME
				+ " where candidate_id = ?;";

		Connection conn = DBPool.getInstance().getConnection();

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, candidate_id);

			rs = pstmt.executeQuery();

			while (rs.next()) {
				GovernmentProject g = new GovernmentProject();
				g.setGovernment_project_id(rs.getInt(GovernmentProject.GOVERNMENTPROJECT_GOVERNMENT_PROJECT_ID));
				g.setCandidate_int(rs.getInt(GovernmentProject.GOVERNMENTPROJECT_CANDIDATE_ID));
				g.setTitle(rs.getString(GovernmentProject.GOVERNMENTPROJECT_TITLE));
				g.setDescription(rs.getString(GovernmentProject.GOVERNMENTPROJECT_DESCRIPTION));

				governmentProjects.add(g);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return governmentProjects;
	}
}
