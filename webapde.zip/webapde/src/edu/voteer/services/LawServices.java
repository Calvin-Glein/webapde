package edu.voteer.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import edu.voteer.beans.Law;
import edu.voteer.db.DBPool;

public class LawServices {
	public static void addLaw(Law l) {
		String sql = "INSERT INTO " + Law.LAW_TABLE_NAME + " (" + Law.LAW_CANDIDATE_ID + ", " + Law.LAW_TITLE + ", "
				+ Law.LAW_AKA + ", " + Law.LAW_DATE + ", " + Law.LAW_DESCRIPTION + ", " + Law.LAW_URL
				+ ") VALUES (?, ?, ?, ?, ?, ?)";

		Connection conn = DBPool.getInstance().getConnection();

		// use preparedstatement to prevent sql injection

		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, l.getCandidate_id());
			pstmt.setString(2, l.getTitle());
			pstmt.setString(3, l.getAka());
			pstmt.setDate(4, l.getDate());
			pstmt.setString(5, l.getDescription());
			pstmt.setString(6, l.getUrl());

			pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	public static ArrayList<Law> getAllLaw() {
		ArrayList<Law> laws = new ArrayList<>();

		String sql = "Select * from " + Law.LAW_TABLE_NAME + ";";

		Connection conn = DBPool.getInstance().getConnection();

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				Law l = new Law();
				l.setLaw_id(rs.getInt(Law.LAW_LAW_ID));
				l.setCandidate_id(rs.getInt(Law.LAW_CANDIDATE_ID));
				l.setTitle(rs.getString(Law.LAW_TITLE));
				l.setAka(rs.getString(Law.LAW_AKA));
				l.setDate(rs.getDate(Law.LAW_DATE));
				l.setDescription(rs.getString(Law.LAW_DESCRIPTION));
				l.setUrl(rs.getString(Law.LAW_URL));

				laws.add(l);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return laws;
	}

	public static void updateLaw(Law l) {
		String sql = "UPDATE " + Law.LAW_TABLE_NAME + " SET " + Law.LAW_CANDIDATE_ID + " = ?, " + Law.LAW_TITLE
				+ " = ?, " + Law.LAW_AKA + " = ?, " + Law.LAW_DATE + " = ?, " + Law.LAW_DESCRIPTION + " = ?, "
				+ Law.LAW_URL + " = ? " + " WHERE " + Law.LAW_LAW_ID + " = ?;";

		Connection conn = DBPool.getInstance().getConnection();
		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, l.getCandidate_id());
			pstmt.setString(2, l.getTitle());
			pstmt.setString(3, l.getAka());
			pstmt.setDate(4, l.getDate());
			pstmt.setString(5, l.getDescription());
			pstmt.setString(6, l.getUrl());
			pstmt.setInt(7, l.getLaw_id());

			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}

	public static void deleteLaw(int law_id) {

		String sql = "DELETE FROM " + Law.LAW_TABLE_NAME + " WHERE " + Law.LAW_LAW_ID + " =?";

		Connection conn = DBPool.getInstance().getConnection();

		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, law_id);

			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}

	public static ArrayList<Law> getAllLawByCandidate(int candidate_id) {
		ArrayList<Law> laws = new ArrayList<>();

		String sql = "Select * from " + Law.LAW_TABLE_NAME + " where candidate_id = ?;";

		Connection conn = DBPool.getInstance().getConnection();

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, candidate_id);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				Law l = new Law();
				l.setLaw_id(rs.getInt(Law.LAW_LAW_ID));
				l.setCandidate_id(rs.getInt(Law.LAW_CANDIDATE_ID));
				l.setTitle(rs.getString(Law.LAW_TITLE));
				l.setAka(rs.getString(Law.LAW_AKA));
				l.setDate(rs.getDate(Law.LAW_DATE));
				l.setDescription(rs.getString(Law.LAW_DESCRIPTION));
				l.setUrl(rs.getString(Law.LAW_URL));
				l.setDateString(l.getDate());
				laws.add(l);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return laws;
	}
}
