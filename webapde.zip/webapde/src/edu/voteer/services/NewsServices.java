package edu.voteer.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import edu.voteer.beans.Law;
import edu.voteer.beans.News;
import edu.voteer.db.DBPool;

public class NewsServices {
	public static void addNews(News n) {
		String sql = "INSERT INTO " + News.NEWS_TABLE_NAME + " (" + News.NEWS_CANDIDATE_ID + ", " + News.NEWS_TITLE
				+ ", " + News.NEWS_URL + ", " + News.NEWS_CONTENT + ", " + News.NEWS_URL + ") VALUES (?, ?, ?, ?, ?)";

		Connection conn = DBPool.getInstance().getConnection();

		// use preparedstatement to prevent sql injection

		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, n.getCandidate_id());
			pstmt.setString(2, n.getTitle());
			pstmt.setString(3, n.getUrl());
			pstmt.setString(4, n.getContent());
			pstmt.setDate(5, n.getDate());

			pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	public static ArrayList<News> getAllNews() {
		ArrayList<News> news = new ArrayList<>();

		String sql = "Select * from " + News.NEWS_TABLE_NAME + ";";

		Connection conn = DBPool.getInstance().getConnection();

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				News l = new News();
				l.setNews_id(rs.getInt(News.NEWS_NEWS_ID));
				l.setCandidate_id(rs.getInt(News.NEWS_CANDIDATE_ID));
				l.setTitle(rs.getString(News.NEWS_TITLE));
				l.setUrl(rs.getString(News.NEWS_URL));
				l.setContent(rs.getString(News.NEWS_CONTENT));
				l.setDate(rs.getDate(News.NEWS_DATE));

				l.setDateString(l.getDate());
				news.add(l);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return news;
	}

	public static void updateNews(News n) {
		String sql = "UPDATE " + News.NEWS_TABLE_NAME + " SET " + News.NEWS_CANDIDATE_ID + " = ?, " + News.NEWS_TITLE
				+ " = ?, " + News.NEWS_URL + " = ?, " + News.NEWS_CONTENT + " = ?, " + News.NEWS_DATE + " = ? "
				+ " WHERE " + News.NEWS_NEWS_ID + " = ?;";

		Connection conn = DBPool.getInstance().getConnection();
		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, n.getCandidate_id());
			pstmt.setString(2, n.getTitle());
			pstmt.setString(3, n.getUrl());
			pstmt.setString(4, n.getContent());
			pstmt.setDate(5, n.getDate());

			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}

	public static void deleteNews(int news_id) {

		String sql = "DELETE FROM " + News.NEWS_TABLE_NAME + " WHERE " + News.NEWS_NEWS_ID + " =?";

		Connection conn = DBPool.getInstance().getConnection();

		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, news_id);

			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}

	/*
	 * public static ArrayList<Law> getAllNewsByCandidate(int candidate_id) {
	 * ArrayList<Law> laws = new ArrayList<>(); String sql = "Select * from " +
	 * News.NEWS_TABLE_NAME + " where candidate_id = ?;";
	 * 
	 * Connection conn = DBPool.getInstance().getConnection();
	 * 
	 * PreparedStatement pstmt = null; ResultSet rs = null; try { pstmt =
	 * conn.prepareStatement(sql); pstmt.setInt(1, candidate_id); rs =
	 * pstmt.executeQuery();
	 * 
	 * while (rs.next()) { News l = new News();
	 * l.setNews_id(rs.getInt(News.NEWS_NEWS_ID));
	 * l.setCandidate_id(rs.getInt(News.NEWS_CANDIDATE_ID));
	 * l.setTitle(rs.getString(News.NEWS_TITLE));
	 * l.setUrl(rs.getString(News.NEWS_URL));
	 * l.setContent(rs.getString(News.NEWS_CONTENT));
	 * l.setDate(rs.getDate(News.NEWS_DATE));
	 * 
	 * l.setDateString(l.getDate()); } } catch (SQLException e) { // TODO
	 * Auto-generated catch block e.printStackTrace(); } finally { try {
	 * pstmt.close(); conn.close(); rs.close(); } catch (SQLException e) { //
	 * TODO Auto-generated catch block e.printStackTrace(); }
	 * 
	 * }
	 * 
	 * return laws; }
	 */
	public static News getNew(int news_id) {
		News l = new News();
		String sql = "Select * from " + News.NEWS_TABLE_NAME + " where news_id = ?;";

		Connection conn = DBPool.getInstance().getConnection();

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, news_id);
			rs = pstmt.executeQuery();

			while (rs.next()) {

				l.setNews_id(rs.getInt(News.NEWS_NEWS_ID));
				l.setCandidate_id(rs.getInt(News.NEWS_CANDIDATE_ID));
				l.setTitle(rs.getString(News.NEWS_TITLE));
				l.setUrl(rs.getString(News.NEWS_URL));
				l.setContent(rs.getString(News.NEWS_CONTENT));
				l.setDate(rs.getDate(News.NEWS_DATE));

				l.setDateString(l.getDate());
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return l;
	}
}
