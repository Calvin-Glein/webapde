package edu.voteer.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import edu.voteer.beans.GovernmentHistoryAchievement;
import edu.voteer.db.DBPool;

public class GovernmentHistoryAchievementServices {
	public static void addGovernmentHistoryAchievement(GovernmentHistoryAchievement g) {
		String sql = "INSERT INTO " + GovernmentHistoryAchievement.GOVERNMENTHISTORYACHIEVEMENT_TABLE_NAME + " ("
				+ GovernmentHistoryAchievement.GOVERNMENTHISTORYACHIEVEMENT_GOVERNMENT_HISTORY_ID + ", "
				+ GovernmentHistoryAchievement.GOVERNMENTHISTORYACHIEVEMENT_POSITION + ") VALUES (?, ?)";

		Connection conn = DBPool.getInstance().getConnection();

		// use preparedstatement to prevent sql injection

		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, g.getGovernment_history_id());
			pstmt.setString(2, g.getPosition());

			pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	public static ArrayList<GovernmentHistoryAchievement> getAllGovernmentHistoryAchievement() {
		ArrayList<GovernmentHistoryAchievement> governmentHistoryAchievements = new ArrayList<>();

		String sql = "Select * from " + GovernmentHistoryAchievement.GOVERNMENTHISTORYACHIEVEMENT_TABLE_NAME + ";";

		Connection conn = DBPool.getInstance().getConnection();

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				GovernmentHistoryAchievement g = new GovernmentHistoryAchievement();
				g.setGovernment_history_achievement_id(rs.getInt(
						GovernmentHistoryAchievement.GOVERNMENTHISTORYACHIEVEMENT_GOVERNMENT_HISTORY_ACHIEVEMENT_ID));
				g.setGovernment_history_id(
						rs.getInt(GovernmentHistoryAchievement.GOVERNMENTHISTORYACHIEVEMENT_GOVERNMENT_HISTORY_ID));
				g.setPosition(rs.getString(GovernmentHistoryAchievement.GOVERNMENTHISTORYACHIEVEMENT_POSITION));

				governmentHistoryAchievements.add(g);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return governmentHistoryAchievements;
	}

	public static void updateGovernmentHistoryAchievement(GovernmentHistoryAchievement g) {
		String sql = "UPDATE " + GovernmentHistoryAchievement.GOVERNMENTHISTORYACHIEVEMENT_TABLE_NAME + " SET "
				+ GovernmentHistoryAchievement.GOVERNMENTHISTORYACHIEVEMENT_GOVERNMENT_HISTORY_ID + " = ?, " + GovernmentHistoryAchievement.GOVERNMENTHISTORYACHIEVEMENT_POSITION + " = ? "
				+ " WHERE " + GovernmentHistoryAchievement.GOVERNMENTHISTORYACHIEVEMENT_GOVERNMENT_HISTORY_ACHIEVEMENT_ID + " = ?;";

		Connection conn = DBPool.getInstance().getConnection();
		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, g.getGovernment_history_id());
			pstmt.setString(2, g.getPosition());
			pstmt.setInt(3, g.getGovernment_history_achievement_id());

			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}

	public static void deleteGovernmentHistoryAchievement(int government_histroy_achievement_id) {

		String sql = "DELETE FROM " + GovernmentHistoryAchievement.GOVERNMENTHISTORYACHIEVEMENT_TABLE_NAME + " WHERE "
				+ GovernmentHistoryAchievement.GOVERNMENTHISTORYACHIEVEMENT_GOVERNMENT_HISTORY_ACHIEVEMENT_ID + " =?";

		Connection conn = DBPool.getInstance().getConnection();

		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, government_histroy_achievement_id);

			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}

	}
}
