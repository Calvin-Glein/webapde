package edu.voteer.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;

import edu.voteer.beans.GovernmentProject;
import edu.voteer.beans.Suggestion;
import edu.voteer.db.DBPool;

public class SuggestionServices {
	public static void addSuggestions(Suggestion s) {
		String sql = "INSERT INTO " + Suggestion.SUGGESTION_TABLE_NAME + " (" + Suggestion.SUGGESTION_NAME + ", "
				+ Suggestion.SUGGESTION_EMAIL + ", " + Suggestion.SUGGESTION_CONTENT + ", " + Suggestion.SUGGESTION_DATE
				+ ") VALUES (?, ?,?, ?)";

		Connection conn = DBPool.getInstance().getConnection();

		// use preparedstatement to prevent sql injection

		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, s.getName());

			pstmt.setString(2, s.getEmail());
			pstmt.setString(3, s.getContent());
			pstmt.setTimestamp(4, new Timestamp(new Date().getTime()));

			pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	public static ArrayList<GovernmentProject> getAllGovernmentProject() {
		ArrayList<GovernmentProject> governmentProjects = new ArrayList<>();

		String sql = "Select * from " + GovernmentProject.GOVERNMENTPROJECT_GOVERNMENTPROJECT_TABLE_NAME + ";";

		Connection conn = DBPool.getInstance().getConnection();

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				GovernmentProject g = new GovernmentProject();
				g.setGovernment_project_id(rs.getInt(GovernmentProject.GOVERNMENTPROJECT_GOVERNMENT_PROJECT_ID));
				g.setCandidate_int(rs.getInt(GovernmentProject.GOVERNMENTPROJECT_CANDIDATE_ID));
				g.setTitle(rs.getString(GovernmentProject.GOVERNMENTPROJECT_TITLE));
				g.setDescription(rs.getString(GovernmentProject.GOVERNMENTPROJECT_DESCRIPTION));

				governmentProjects.add(g);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return governmentProjects;
	}

}
