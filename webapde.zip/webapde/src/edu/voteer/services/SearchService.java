package edu.voteer.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import edu.voteer.beans.Candidate;
import edu.voteer.db.DBPool;

public class SearchService {
	public static ArrayList<Candidate> getCandidates(String keyword) {
		ArrayList<Candidate> candidates = new ArrayList<>();

		String sql = "SELECT * from candidates where firstname LIKE ? or nickname LIKE ? or middlename LIKE ? or lastname LIKE ? or birthdate LIKE ? or father LIKE ? or mother LIKE ? or religion LIKE ? or picture LIKE ? or description LIKE ?;";

		Connection conn = DBPool.getInstance().getConnection();

		PreparedStatement pstmt = null;
		System.out.println("KEY" + keyword);
		String keywordWildcard = "%" + keyword + "%";
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			for (int i = 1; i <= 10; i++) {
				pstmt.setString(i, keywordWildcard);
			}

			rs = pstmt.executeQuery();

			while (rs.next()) {
				Candidate c = new Candidate();
				c.setCandidate_id(rs.getInt(Candidate.CANDIDATE_CANDIDATE_ID));
				c.setFirstname(rs.getString(Candidate.CANDIDATE_FIRSTNAME));
				c.setNickname(rs.getString(Candidate.CANDIDATE_NICKNAME));
				c.setMiddlename(rs.getString(Candidate.CANDIDATE_MIDDLENAME));
				c.setLastname(rs.getString(Candidate.CANDIDATE_LASTNAME));
				c.setBirthdate(rs.getDate(Candidate.CANDIDATE_BIRTHDATE));
				c.setFather(rs.getString(Candidate.CANDIDATE_FATHER));
				c.setMother(rs.getString(Candidate.CANDIDATE_MOTHER));
				c.setReligion(rs.getString(Candidate.CANDIDATE_RELIGION));
				c.setPicture(rs.getString(Candidate.CANDIDATE_PICTURE));
				c.setPosition(rs.getString(Candidate.CANDIDATE_POSITION));
				c.setDescription(rs.getString(Candidate.CANDIDATE_DESCRIPTION));

				System.out.println(c.getNickname());
				System.out.println("SUPOT");
				candidates.add(c);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return candidates;
	}

}
