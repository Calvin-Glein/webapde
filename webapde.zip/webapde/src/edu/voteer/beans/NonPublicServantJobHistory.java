package edu.voteer.beans;

import java.io.Serializable;

public class NonPublicServantJobHistory implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static final String NONPUBLICSERVANTJOBHISTORY_TABLE_NAME = "non_public_servant_job_history";
	public static final String NONPUBLICSERVANTJOBHISTORY_NON_PUBLIC_SERVANT_JOB_HISTORY_ID = "non_public_servant_job_history_id";
	public static final String NONPUBLICSERVANTJOBHISTORY_CANDIDATE_ID = "candidate_id";
	public static final String NONPUBLICSERVANTJOBHISTORY_POSITION = "position";
	public static final String NONPUBLICSERVANTJOBHISTORY_INSTITUTION = "institution";


	private int non_public_servant_job_history_id;
	private int candidate_id;
	private String position;
	private String institution;

	public NonPublicServantJobHistory() {

	}

	public NonPublicServantJobHistory(int non_public_servant_job_history_id, int candidate_id, String position, String institution) {
		super();
		this.non_public_servant_job_history_id = non_public_servant_job_history_id;
		this.candidate_id = candidate_id;
		this.position = position;
		this.institution = institution;
	}

	public NonPublicServantJobHistory(int candidate_id, String position) {
		super();
		this.non_public_servant_job_history_id = non_public_servant_job_history_id;
		this.candidate_id = candidate_id;
		this.position = position;
	}

	public int getNon_public_servant_job_history_id() {
		return non_public_servant_job_history_id;
	}

	public void setNon_public_servant_job_history_id(int non_public_servant_job_history_id) {
		this.non_public_servant_job_history_id = non_public_servant_job_history_id;
	}

	public int getCandidate_id() {
		return candidate_id;
	}

	public void setCandidate_id(int candidate_id) {
		this.candidate_id = candidate_id;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}
	
	public String getInstitution() {
		return institution;
	}

	public void setInstitution(String institution) {
		this.institution = institution;
	}

}
