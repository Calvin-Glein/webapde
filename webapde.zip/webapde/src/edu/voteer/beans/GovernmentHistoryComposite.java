
package edu.voteer.beans;

public class GovernmentHistoryComposite {
	private int government_history_achievement_id;
	private int government_history_id;
	private String position;
	private int candidate_id;
	private String institution;

	public GovernmentHistoryComposite() {

	}

	public GovernmentHistoryComposite(int government_history_achievement_id, int government_history_id, String position,
			int candidate_id, String institution) {
		super();
		this.government_history_achievement_id = government_history_achievement_id;
		this.government_history_id = government_history_id;
		this.position = position;
		this.candidate_id = candidate_id;
		this.institution = institution;
	}

	public int getGovernment_history_achievement_id() {
		return government_history_achievement_id;
	}

	public void setGovernment_history_achievement_id(int government_history_achievement_id) {
		this.government_history_achievement_id = government_history_achievement_id;
	}

	public int getGovernment_history_id() {
		return government_history_id;
	}

	public void setGovernment_history_id(int government_history_id) {
		this.government_history_id = government_history_id;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public int getCandidate_id() {
		return candidate_id;
	}

	public void setCandidate_id(int candidate_id) {
		this.candidate_id = candidate_id;
	}

	public String getInstitution() {
		return institution;
	}

	public void setInstitution(String institution) {
		this.institution = institution;
	}

}
