package edu.voteer.beans;

import java.io.Serializable;
import java.sql.Date;

public class Suggestion implements Serializable {
	private static final long serialVersionUID = 1L;
	public static final String SUGGESTION_TABLE_NAME = "suggestions";
	public static final String SUGGESTION_ID = "suggestion_id";
	public static final String SUGGESTION_EMAIL = "email";
	public static final String SUGGESTION_CONTENT = "content";
	public static final String SUGGESTION_NAME = "name";
	public static final String SUGGESTION_DATE = "date";

	private int suggestion_id;
	private String email;
	private String content;
	private String name;
	private Date date;

	public Suggestion() {

	}

	public Suggestion(int suggestion_id, String email, String content, String name, Date date) {
		super();
		this.suggestion_id = suggestion_id;
		this.email = email;
		this.content = content;
		this.name = name;
		this.date = date;
	}

	public Suggestion(String name, String email, String content) {
		// TODO Auto-generated constructor stub
		this.email = email;
		this.content = content;
		this.name = name;
	}

	public int getSuggestion_id() {
		return suggestion_id;
	}

	public void setSuggestion_id(int suggestion_id) {
		this.suggestion_id = suggestion_id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

}
