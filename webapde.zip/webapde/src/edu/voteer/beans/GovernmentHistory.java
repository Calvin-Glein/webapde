package edu.voteer.beans;

import java.io.Serializable;

public class GovernmentHistory implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static final String GOVERNMENTHISTORY_TABLE_NAME  = "government_history";
	public static final String GOVERNMENTHISTORY_GOVERNMENT_HISTORY_ID = "government_history_id";
	public static final String GOVERNMENTHISTORY_CANDIDATE_ID = "candidate_id";
	public static final String GOVERNMENTHISTORY_INSTITUTION = "institution";

	
	private int government_history_id;
	private int candidate_id;
	private String institution;
	
	
	public GovernmentHistory(){
		
	}
	public GovernmentHistory(int government_history_id, int candidate_id, String institution) {
		super();
		this.government_history_id = government_history_id;
		this.candidate_id = candidate_id;
		this.institution = institution;
	}
	public GovernmentHistory(int candidate_id, String institution) {
		super();
		this.candidate_id = candidate_id;
		this.institution = institution;
	}
	public int getGovernment_history_id() {
		return government_history_id;
	}
	public void setGovernment_history_id(int government_history_id) {
		this.government_history_id = government_history_id;
	}
	public int getCandidate_id() {
		return candidate_id;
	}
	public void setCandidate_id(int candidate_id) {
		this.candidate_id = candidate_id;
	}
	public String getInstitution() {
		return institution;
	}
	public void setInstitution(String institution) {
		this.institution = institution;
	}
	
	
}
