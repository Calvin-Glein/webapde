package edu.voteer.beans;

import java.io.Serializable;

public class GovernmentHistoryAchievement implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static final String GOVERNMENTHISTORYACHIEVEMENT_TABLE_NAME = "government_history_achievements";
	public static final String GOVERNMENTHISTORYACHIEVEMENT_GOVERNMENT_HISTORY_ACHIEVEMENT_ID = "government_history_achievement_id";
	public static final String GOVERNMENTHISTORYACHIEVEMENT_GOVERNMENT_HISTORY_ID = "government_history_id";
	public static final String GOVERNMENTHISTORYACHIEVEMENT_POSITION = "position";

	private int government_history_achievement_id;
	private int government_history_id;
	private String position;

	public GovernmentHistoryAchievement() {

	}

	public GovernmentHistoryAchievement(int government_history_achievement_id, int government_history_id,
			String position) {
		super();
		this.government_history_achievement_id = government_history_achievement_id;
		this.government_history_id = government_history_id;
		this.position = position;
	}

	public int getGovernment_history_achievement_id() {
		return government_history_achievement_id;
	}

	public void setGovernment_history_achievement_id(int government_history_achievement_id) {
		this.government_history_achievement_id = government_history_achievement_id;
	}

	public int getGovernment_history_id() {
		return government_history_id;
	}

	public void setGovernment_history_id(int government_history_id) {
		this.government_history_id = government_history_id;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

}
