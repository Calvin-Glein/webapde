package edu.voteer.beans;

import java.io.Serializable;
import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class News implements Serializable {
	public static final String NEWS_TABLE_NAME = "news";
	public static final String NEWS_NEWS_ID = "news_id";
	public static final String NEWS_CANDIDATE_ID = "candidate_id";
	public static final String NEWS_TITLE = "title";
	public static final String NEWS_URL = "url";
	public static final String NEWS_CONTENT = "content";
	public static final String NEWS_DATE = "date";

	private int news_id;
	private String title;
	private String url;
	private String content;
	private Date date;
	private String dateString;
	private int candidate_id;

	public News(int news_id, String title, String url, String content, Date date, String dateString,
			int candidate_id) {
		super();
		this.news_id = news_id;
		this.title = title;
		this.url = url;
		this.content = content;
		this.date = date;
		this.dateString = dateString;
		this.candidate_id = candidate_id;
	}

	public int getCandidate_id() {
		return candidate_id;
	}

	public void setCandidate_id(int candidate_id) {
		this.candidate_id = candidate_id;
	}

	public News() {

	}

	public int getNews_id() {
		return news_id;
	}

	public void setNews_id(int news_id) {
		this.news_id = news_id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getDateString() {
		return dateString;
	}

	public void setDateString(String dateString) {
		this.dateString = dateString;
	}

	public void setDateString(Date date) {

		java.util.Date utilDate = new java.util.Date(date.getTime());

		DateFormat format2 = new SimpleDateFormat("MMMMM dd, yyyy");
		String dateString = format2.format(utilDate);
		this.dateString = dateString;
	}

}
