package edu.voteer.beans;

public class AcademicComposite {
	private int academic_award_id;
	private int academic_id;
	private String award_title;
	private String degree;
	private String institution;
	private int candidate_id;

	public AcademicComposite(int academic_award_id, int academic_id, String award_title, String degree,
			String institution, int candidate_id) {
		super();
		this.academic_award_id = academic_award_id;
		this.academic_id = academic_id;
		this.award_title = award_title;
		this.degree = degree;
		this.institution = institution;
		this.candidate_id = candidate_id;
	}

	public AcademicComposite() {

	}

	
	public int getCandidate_id() {
		return candidate_id;
	}

	public void setCandidate_id(int candidate_id) {
		this.candidate_id = candidate_id;
	}

	public int getAcademic_award_id() {
		return academic_award_id;
	}

	public void setAcademic_award_id(int academic_award_id) {
		this.academic_award_id = academic_award_id;
	}

	public int getAcademic_id() {
		return academic_id;
	}

	public void setAcademic_id(int academic_id) {
		this.academic_id = academic_id;
	}

	public String getAward_title() {
		return award_title;
	}

	public void setAward_title(String award_title) {
		this.award_title = award_title;
	}

	public String getDegree() {
		return degree;
	}

	public void setDegree(String degree) {
		this.degree = degree;
	}

	public String getInstitution() {
		return institution;
	}

	public void setInstitution(String institution) {
		this.institution = institution;
	}
}
